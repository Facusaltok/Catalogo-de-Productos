import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Monaco Detailing - Productos Premium para Detailing Automotriz",
  description: "Especialistas en detailing automotriz con productos de alta calidad. Ceras, selladores, limpiadores y accesorios para el cuidado profesional de tu vehículo.",
  keywords: ["detailing", "automotriz", "ceras", "selladores", "limpieza", "Monaco Detailing", "car care", "protección vehicular"],
  authors: [{ name: "Monaco Detailing" }],
  openGraph: {
    title: "Monaco Detailing - Productos Premium para Detailing",
    description: "Productos de alta calidad para el cuidado profesional de tu vehículo",
    url: "https://monacodetailing.com",
    siteName: "Monaco Detailing",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Monaco Detailing",
    description: "Productos premium para detailing automotriz",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
