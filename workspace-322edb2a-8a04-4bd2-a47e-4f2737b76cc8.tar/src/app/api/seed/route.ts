import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST() {
  try {
    // Create categories
    const categories = await Promise.all([
      db.category.upsert({
        where: { slug: 'ceras-selladores' },
        update: {},
        create: {
          name: 'Ceras y Selladores',
          slug: 'ceras-selladores',
          description: 'Protección duradera y brillo excepcional para tu vehículo'
        }
      }),
      db.category.upsert({
        where: { slug: 'limpieza-exterior' },
        update: {},
        create: {
          name: 'Limpieza Exterior',
          slug: 'limpieza-exterior',
          description: 'Productos para una limpieza profunda del exterior'
        }
      }),
      db.category.upsert({
        where: { slug: 'interior' },
        update: {},
        create: {
          name: 'Interior',
          slug: 'interior',
          description: 'Cuidado y limpieza del interior del vehículo'
        }
      }),
      db.category.upsert({
        where: { slug: 'accesorios' },
        update: {},
        create: {
          name: 'Accesorios',
          slug: 'accesorios',
          description: 'Herramientas y aplicadores profesionales'
        }
      })
    ])

    // Create sample products
    const products = await Promise.all([
      db.product.upsert({
        where: { sku: 'CERA-001' },
        update: {},
        create: {
          name: 'Cera Sintética Premium',
          description: 'Cera de alta duración con protección UV y brillo intenso. Fórmula avanzada para protección hasta 6 meses.',
          price: 8900,
          comparePrice: 12000,
          sku: 'CERA-001',
          stock: 50,
          images: JSON.stringify([
            'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=400',
            'https://images.unsplash.com/photo-1605559424843-9e4c228bf1c2?w=400'
          ]),
          categoryId: categories[0].id,
          featured: true,
          status: 'active',
          tags: JSON.stringify(['cera', 'proteccion', 'brillo', 'sintetica'])
        }
      }),
      db.product.upsert({
        where: { sku: 'SELL-002' },
        update: {},
        create: {
          name: 'Sellador Cerámico 3D',
          description: 'Sellador cerámico de última generación con tecnología nanotecnológica. Protección extrema contra contaminantes.',
          price: 15000,
          comparePrice: 18000,
          sku: 'SELL-002',
          stock: 30,
          images: JSON.stringify([
            'https://images.unsplash.com/photo-1616457818842-91cdf80d0c8f?w=400',
            'https://images.unsplash.com/photo-1542362567-b07e54358753?w=400'
          ]),
          categoryId: categories[0].id,
          featured: true,
          status: 'active',
          tags: JSON.stringify(['sellador', 'ceramico', 'nanotecnologia', 'proteccion'])
        }
      }),
      db.product.upsert({
        where: { sku: 'LIMP-003' },
        update: {},
        create: {
          name: 'Shampoo pH Neutro',
          description: 'Shampoo de limpieza suave con pH neutro. Seguro para ceras y selladores previamente aplicados.',
          price: 3500,
          comparePrice: 4500,
          sku: 'LIMP-003',
          stock: 100,
          images: JSON.stringify([
            'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400',
            'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400'
          ]),
          categoryId: categories[1].id,
          featured: false,
          status: 'active',
          tags: JSON.stringify(['shampoo', 'limpieza', 'ph-neutro', 'seguro'])
        }
      }),
      db.product.upsert({
        where: { sku: 'LIMP-004' },
        update: {},
        create: {
          name: 'Limpiador de Rines',
          description: 'Limpiador especializado para rines y llantas. Elimina residuos de freno y contaminación metálica.',
          price: 4200,
          comparePrice: 5500,
          sku: 'LIMP-004',
          stock: 75,
          images: JSON.stringify([
            'https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=400',
            'https://images.unsplash.com/photo-1600856209923-343c944c8c2d?w=400'
          ]),
          categoryId: categories[1].id,
          featured: true,
          status: 'active',
          tags: JSON.stringify(['rines', 'llantas', 'limpiador', 'metal'])
        }
      }),
      db.product.upsert({
        where: { sku: 'INT-005' },
        update: {},
        create: {
          name: 'Limpiador de Tapicería',
          description: 'Limpiador multiusos para tapicería de tela y vinilo. Elimina manchas y olores sin dañar los materiales.',
          price: 3800,
          comparePrice: 4800,
          sku: 'INT-005',
          stock: 60,
          images: JSON.stringify([
            'https://images.unsplash.com/photo-1549399810-3e166dfb4b2e?w=400',
            'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400'
          ]),
          categoryId: categories[2].id,
          featured: false,
          status: 'active',
          tags: JSON.stringify(['tapiceria', 'interior', 'limpiador', 'manchas'])
        }
      }),
      db.product.upsert({
        where: { sku: 'INT-006' },
        update: {},
        create: {
          name: 'Acondicionador de Cuero',
          description: 'Acondicionador premium para cuero genuino. Nutre, protege y restaura la flexibilidad del cuero.',
          price: 6500,
          comparePrice: 8000,
          sku: 'INT-006',
          stock: 40,
          images: JSON.stringify([
            'https://images.unsplash.com/photo-1549399810-3e166dfb4b2e?w=400',
            'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400'
          ]),
          categoryId: categories[2].id,
          featured: true,
          status: 'active',
          tags: JSON.stringify(['cuero', 'acondicionador', 'nutricion', 'proteccion'])
        }
      }),
      db.product.upsert({
        where: { sku: 'ACC-007' },
        update: {},
        create: {
          name: 'Microfibra Premium (12 unidades)',
          description: 'Paños de microfibra de alta calidad. Suaves, absorbentes y seguros para todas las superficies.',
          price: 2800,
          comparePrice: 3500,
          sku: 'ACC-007',
          stock: 200,
          images: JSON.stringify([
            'https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?w=400',
            'https://images.unsplash.com/photo-1524863479829-916d8e77f114?w=400'
          ]),
          categoryId: categories[3].id,
          featured: false,
          status: 'active',
          tags: JSON.stringify(['microfibra', 'paños', 'limpieza', 'accesorios'])
        }
      }),
      db.product.upsert({
        where: { sku: 'ACC-008' },
        update: {},
        create: {
          name: 'Aplicador de Cera Doble Cara',
          description: 'Aplicador profesional con dos superficies: una para aplicación y otra para pulido.',
          price: 1800,
          comparePrice: 2400,
          sku: 'ACC-008',
          stock: 150,
          images: JSON.stringify([
            'https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?w=400',
            'https://images.unsplash.com/photo-1524863479829-916d8e77f114?w=400'
          ]),
          categoryId: categories[3].id,
          featured: false,
          status: 'active',
          tags: JSON.stringify(['aplicador', 'cera', 'herramienta', 'profesional'])
        }
      })
    ])

    return NextResponse.json({
      message: 'Database seeded successfully',
      categories: categories.length,
      products: products.length
    })
  } catch (error) {
    console.error('Error seeding database:', error)
    return NextResponse.json(
      { error: 'Error seeding database' },
      { status: 500 }
    )
  }
}