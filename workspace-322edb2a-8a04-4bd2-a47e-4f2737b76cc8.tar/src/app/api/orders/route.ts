import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    // Generate order number
    const orderNumber = `ORD-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`
    
    // Create user if not exists (simplified for demo)
    let user = await db.user.findUnique({
      where: { email: body.customerInfo.email }
    })
    
    if (!user) {
      user = await db.user.create({
        data: {
          email: body.customerInfo.email,
          name: `${body.customerInfo.firstName} ${body.customerInfo.lastName}`,
          phone: body.customerInfo.phone,
          address: `${body.shippingAddress.address}, ${body.shippingAddress.city}, ${body.shippingAddress.province} ${body.shippingAddress.postalCode}`
        }
      })
    }
    
    // Create order
    const order = await db.order.create({
      data: {
        userId: user.id,
        orderNumber,
        status: 'pending',
        subtotal: body.subtotal,
        tax: body.tax,
        shipping: body.shipping,
        total: body.total,
        notes: body.notes,
        shippingAddress: JSON.stringify(body.shippingAddress),
        paymentMethod: body.paymentMethod,
        paymentStatus: 'pending'
      }
    })
    
    // Create order items
    const orderItems = await Promise.all(
      body.items.map((item: any) =>
        db.orderItem.create({
          data: {
            orderId: order.id,
            productId: item.productId,
            quantity: item.quantity,
            price: item.price,
            total: item.total
          }
        })
      )
    )
    
    // Update product stock
    await Promise.all(
      body.items.map((item: any) =>
        db.product.update({
          where: { id: item.productId },
          data: {
            stock: {
              decrement: item.quantity
            }
          }
        })
      )
    )
    
    return NextResponse.json({
      ...order,
      items: orderItems
    }, { status: 201 })
    
  } catch (error) {
    console.error('Error creating order:', error)
    return NextResponse.json(
      { error: 'Error creating order' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const status = searchParams.get('status')
    
    const where: any = {}
    
    if (userId) {
      where.userId = userId
    }
    
    if (status) {
      where.status = status
    }
    
    const orders = await db.order.findMany({
      where,
      include: {
        items: {
          include: {
            product: true
          }
        },
        user: true
      },
      orderBy: {
        createdAt: 'desc'
      }
    })
    
    return NextResponse.json(orders)
    
  } catch (error) {
    console.error('Error fetching orders:', error)
    return NextResponse.json(
      { error: 'Error fetching orders' },
      { status: 500 }
    )
  }
}