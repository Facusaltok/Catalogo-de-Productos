'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'

interface Category {
  id: string
  name: string
  description: string
  image?: string
  slug: string
}

export function Categories() {
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await fetch('/api/categories')
        if (response.ok) {
          const data = await response.json()
          setCategories(data)
        }
      } catch (error) {
        console.error('Error fetching categories:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchCategories()
  }, [])

  const defaultCategories = [
    {
      id: '1',
      name: 'Ceras y Selladores',
      description: 'Protección duradera y brillo excepcional',
      image: '/images/category-ceras.jpg',
      slug: 'ceras-selladores'
    },
    {
      id: '2',
      name: 'Limpieza Exterior',
      description: 'Productos para una limpieza profunda',
      image: '/images/category-limpieza.jpg',
      slug: 'limpieza-exterior'
    },
    {
      id: '3',
      name: 'Interior',
      description: 'Cuidado y limpieza del interior',
      image: '/images/category-interior.jpg',
      slug: 'interior'
    },
    {
      id: '4',
      name: 'Accesorios',
      description: 'Herramientas y aplicadores profesionales',
      image: '/images/category-accesorios.jpg',
      slug: 'accesorios'
    }
  ]

  const displayCategories = categories.length > 0 ? categories : defaultCategories

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Categorías Populares
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Explora nuestras categorías de productos especializados para el cuidado de tu vehículo
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {displayCategories.map((category) => (
            <Link key={category.id} href={`/categorias/${category.slug}`}>
              <Card className="group cursor-pointer overflow-hidden transition-all hover:shadow-lg">
                <CardContent className="p-0">
                  <div className="relative aspect-square overflow-hidden">
                    <Image
                      src={category.image || `/images/category-${category.slug}.jpg`}
                      alt={category.name}
                      fill
                      className="object-cover transition-transform group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    <div className="absolute bottom-4 left-4 right-4 text-white">
                      <h3 className="text-xl font-bold mb-2">{category.name}</h3>
                      <p className="text-sm text-gray-200 line-clamp-2">
                        {category.description}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        <div className="text-center">
          <Link href="/categorias">
            <Button variant="outline" size="lg">
              Ver Todas las Categorías
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}