'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { ArrowRight, Play, Star } from 'lucide-react'
import Link from 'next/link'

export function Hero() {
  const [currentSlide, setCurrentSlide] = useState(0)
  
  const slides = [
    {
      title: "Protección Premium para tu Vehículo",
      subtitle: "Productos de detailing de alta calidad",
      description: "Descubre nuestra línea completa de ceras, selladores y accesorios para mantener tu vehículo como nuevo.",
      image: "/images/hero-1.jpg",
      cta: "Ver Productos",
      ctaLink: "/productos"
    },
    {
      title: "Detalle Profesional",
      subtitle: "Resultados de showroom",
      description: "Transforma el aspecto de tu vehículo con nuestros productos profesionales de detailing.",
      image: "/images/hero-2.jpg",
      cta: "Catálogo Completo",
      ctaLink: "/categorias"
    },
    {
      title: "Envíos a Todo el País",
      subtitle: "Compra online con confianza",
      description: "Recibe tus productos en cualquier parte de Argentina. Envíos seguros y rápidos.",
      image: "/images/hero-3.jpg",
      cta: "Comprar Ahora",
      ctaLink: "/productos"
    }
  ]

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [slides.length])

  return (
    <section className="relative h-[600px] md:h-[700px] overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat transition-opacity duration-1000"
          style={{
            backgroundImage: `url(${slides[currentSlide].image})`,
            opacity: 0.3
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-black/40" />
      </div>

      {/* Content */}
      <div className="relative container mx-auto px-4 h-full flex items-center">
        <div className="max-w-2xl text-white">
          <div className="flex items-center gap-2 mb-4">
            <span className="bg-green-500 text-white px-3 py-1 rounded-full text-sm font-medium">
              {slides[currentSlide].subtitle}
            </span>
            <div className="flex items-center gap-1">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
              ))}
              <span className="text-sm ml-1">4.9/5</span>
            </div>
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
            {slides[currentSlide].title}
          </h1>
          
          <p className="text-lg md:text-xl mb-8 text-gray-200 leading-relaxed">
            {slides[currentSlide].description}
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <Link href={slides[currentSlide].ctaLink}>
              <Button size="lg" className="bg-green-600 hover:bg-green-700 text-white px-8">
                {slides[currentSlide].cta}
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            
            <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-black">
              <Play className="mr-2 h-5 w-5" />
              Ver Demo
            </Button>
          </div>
        </div>
      </div>

      {/* Slide Indicators */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex gap-2">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-3 h-3 rounded-full transition-all ${
              currentSlide === index 
                ? 'bg-white w-8' 
                : 'bg-white/50 hover:bg-white/75'
            }`}
          />
        ))}
      </div>
    </section>
  )
}