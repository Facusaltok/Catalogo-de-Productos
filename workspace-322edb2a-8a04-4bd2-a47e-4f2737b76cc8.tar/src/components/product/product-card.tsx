'use client'

import Link from 'next/link'
import Image from 'next/image'
import { ShoppingCart, Star } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useCart } from '@/hooks/use-cart'
import { toast } from 'sonner'

interface ProductCardProps {
  product: {
    id: string
    name: string
    price: number
    comparePrice?: number
    images: string
    sku: string
    featured?: boolean
    status: string
    category: {
      name: string
      slug: string
    }
  }
}

export function ProductCard({ product }: ProductCardProps) {
  const { addItem } = useCart()
  const images = JSON.parse(product.images || '[]')
  const firstImage = images[0] || '/placeholder-product.jpg'
  
  const discount = product.comparePrice 
    ? Math.round(((product.comparePrice - product.price) / product.comparePrice) * 100)
    : 0

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: firstImage,
      quantity: 1,
      sku: product.sku,
    })
    
    toast.success('Producto agregado al carrito')
  }

  if (product.status !== 'active') {
    return null
  }

  return (
    <Link href={`/producto/${product.id}`}>
      <Card className="group cursor-pointer overflow-hidden transition-all hover:shadow-lg">
        <CardContent className="p-0">
          <div className="relative aspect-square overflow-hidden">
            <Image
              src={firstImage}
              alt={product.name}
              fill
              className="object-cover transition-transform group-hover:scale-105"
            />
            
            {product.featured && (
              <Badge className="absolute top-2 left-2 bg-green-500">
                Destacado
              </Badge>
            )}
            
            {discount > 0 && (
              <Badge className="absolute top-2 right-2 bg-red-500">
                -{discount}%
              </Badge>
            )}
            
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors" />
          </div>
          
          <div className="p-4">
            <div className="mb-2">
              <Badge variant="secondary" className="text-xs">
                {product.category.name}
              </Badge>
            </div>
            
            <h3 className="font-semibold text-lg mb-2 line-clamp-2 group-hover:text-primary transition-colors">
              {product.name}
            </h3>
            
            <div className="flex items-center gap-2 mb-3">
              <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-4 w-4 ${
                      i < 4 ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'
                    }`}
                  />
                ))}
              </div>
              <span className="text-sm text-gray-500">(4.0)</span>
            </div>
            
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="text-2xl font-bold">
                  ${product.price.toLocaleString('es-AR')}
                </span>
                {product.comparePrice && (
                  <span className="text-sm text-gray-500 line-through">
                    ${product.comparePrice.toLocaleString('es-AR')}
                  </span>
                )}
              </div>
            </div>
            
            <Button
              onClick={handleAddToCart}
              className="w-full"
              size="sm"
            >
              <ShoppingCart className="h-4 w-4 mr-2" />
              Agregar al carrito
            </Button>
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}